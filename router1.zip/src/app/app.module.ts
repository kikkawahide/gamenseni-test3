// Angular 2のモジュール参照
import { NgModule }       from "@angular/core";
import { BrowserModule }  from "@angular/platform-browser";
import { RouterModule }   from "@angular/router"

// コンポーネント参照
import { AppComponent }   from "./app.component";
import { HomeComponent }  from "./home.component";
import { Comp1Component } from "./comp1.component";
import { Comp2Component } from "./comp2.component";
import { ErrorComponent } from "./error.component";

@NgModule({
  imports:      [
    BrowserModule,
    // ルーターにルートを指定
    RouterModule.forRoot([
      { path: "comp1", component: Comp1Component },
      { path: "comp2", component: Comp2Component },
      { path: "", component: HomeComponent },
      { path: "**", component: ErrorComponent }
    ])
  ],
  declarations: [
    AppComponent,
    HomeComponent,
    Comp1Component,
    Comp2Component,
    ErrorComponent
  ],
  bootstrap: [ AppComponent ]
})
export class AppModule { }
