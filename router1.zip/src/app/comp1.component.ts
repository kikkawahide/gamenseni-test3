import { Component } from "@angular/core";

@Component({
  // CSSの定義
  styles:["div.component{ background-color:#ffeeaa; }"],
  // テンプレートの定義
  template: `
    <div class="component">
      <h2>コンポーネント1</h2>
      <p>Comp1Componentコンポーネントによる描画です。</p>
    </div>
  `
})
export class Comp1Component { }