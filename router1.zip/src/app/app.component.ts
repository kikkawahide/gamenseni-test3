// Angular 2のモジュール参照 ...（1）
import  { Component }       from "@angular/core";
@Component({
    selector: "my-app",
    template: `
    　<h1>Angular Router サンプル1</h1>
    <!-- ルーターで表示を切り替えるリンク -->
    <a routerLink="/comp1"
    routerLinkActive="active">コンポーネント１</a>
    <a routerLink="/comp2"
    routerLinkActive="active">コンポーネント２</a>
    <a routerLink="/dummy"
    routerLinkActive="active">不整脈</a>


    <!-- ルーターで表示を切り替えるリンク -->
    <router-outlet></router-outlet>
    `
  })
  export class AppComponent { }
