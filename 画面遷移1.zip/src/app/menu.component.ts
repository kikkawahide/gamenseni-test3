				
import { Component } from '@angular/core';

@Component({
    moduleId: module.id,
    template: '<h1>Menu</h1><a routerLink="/login">ログアウト</a>'
})
export class MenuComponent {

}

