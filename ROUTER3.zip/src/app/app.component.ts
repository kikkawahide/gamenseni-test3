// Angular 2のモジュール参照 ...（1）
import  { Component }       from "@angular/core";
import { Router } from "@angular/router";

@Component({
    selector: "my-app",
    template: `
    　<h1>Angular Router サンプル3</h1>

    <!-- ルーターで表示を切り替えるリンク -->
    <a routerLink="['/comp1', {'id': 1234, 'msg': 'Hello'}]"
    routerLinkActive="active">コンポーネント１(ID=1234,MSG=Hello)
    </a>
    
    <a routerLink="/comp2" routerLinkActive="active">コンポーネント2</a>
    <a routerLink="/dummy" routerLinkActive="active">不正なURL</a>
    <br><br>

    <!-- Router.navigateメソッドでコンポーネントを切り替える処理-->
    <input type="text" placeholder="ID" [(ngModel)]="value1">
    <input type="text" placeholder="MSG" [(ngModel)]="value2">
    <button (click)="onClickButton();">コンポーネント1に値を渡して遷移</button>

    <!-- ルーターがコンポーネントを表示する場所 -->
    <router-outlet></router-outlet>
  `
})
export class AppComponent {
  value1:string = "";
  value2:string = "";

  /**
   * コンストラクター
   * 依存性注入でrouterオブジェクトを受け取る
   */
  constructor(private router:Router) {
  }

  /**
   * ボタン押下時の処理
   */
  onClickButton(){
    this.router.navigate(["/comp1", {"id": this.value1, "msg": this.value2}]);
  }
  }
