import { Component } from "@angular/core";
import { ActivatedRoute, Params } from "@angular/router"
@Component({
  // CSSの定義
  styles:["div.component{ background-color:#ffeeaa; }"],
  // テンプレートの定義
  template: `
    <div class="component">
      <h2>コンポーネント1</h2>
      <p>ID={{id}}<br\>
      MSG={{msg}}
      </p>
      </div> 
  `
})
export class Comp1Component { 
 // 画面表示用変数
 id:string = "";
 msg:string = "";
 /**
  * コンストラクター
  * 指定されたパラメーターの情報がrouteに格納される
  */
 constructor(private route: ActivatedRoute) {
   this.route.params.forEach((params: Params) => {
     this.id = params["id"]+"KKK";
     this.msg = params["msg"];
   });
 }

}