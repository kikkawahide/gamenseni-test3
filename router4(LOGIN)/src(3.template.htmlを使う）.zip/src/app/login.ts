
export class Login {
    constructor(
        public name: string,
        public password: string,
        public message?: string
    ) { }
}
