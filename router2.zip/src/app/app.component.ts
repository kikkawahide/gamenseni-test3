// Angular 2のモジュール参照 ...（1）
import  { Component }       from "@angular/core";
import { Router } from "@angular/router";

@Component({
    selector: "my-app",
    template: `
    　<h1>Angular Router サンプル2</h1>

    <!-- ルーターで表示を切り替えるリンク -->
    <a routerLink="/comp1/25"
    routerLinkActive="active">コンポーネント１(ID=25)</a>
    <!--
    <a [routerLink]="['/comp1', 25]" routerLinkActive="active">コンポーネント1（ID=25）</a>
    -->
    <!-- Router.navigateメソッドでコンポーネントを切り替える処理-->
    <input type="text" placeholder="入力1" [(ngModel)]="value1">
    <button (click)="onClickButton();">コンポーネント1に値を渡して遷移</button>

    <!-- ルーターがコンポーネントを表示する場所 -->
    <router-outlet></router-outlet>
  `
  })
  export class AppComponent { 
    value1:string = "";
  
    /**
     * コンストラクター
     * 依存性注入でrouterオブジェクトを受け取る
     */
    constructor(private router:Router) {
    }
    /**
     * ボタン押下時の処理
     */
    onClickButton(){
      this.router.navigate(["/comp1", this.value1]);
    }
  }
