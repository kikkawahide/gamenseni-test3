import { Component } from "@angular/core";

@Component({
  // CSSの定義
  styles:["div.component{ background-color:#aaccff; }"],
  // テンプレートの定義
  template: `
    <div class="component">
      <h2>コンポーネント2</h2>
      <p>Comp2Componentコンポーネントによる描画です。</p>
    </div>
  `
})
export class Comp2Component { }