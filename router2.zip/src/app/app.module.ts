// Angular 2のモジュール参照
// Angular 2のモジュール参照
import { NgModule }       from "@angular/core";
import { BrowserModule }  from "@angular/platform-browser";
import { FormsModule } from "@angular/forms"
import { RouterModule }   from "@angular/router"

// コンポーネント参照
import { AppComponent }   from "./app.component";
import { HomeComponent }  from "./home.component";
import { Comp1Component } from "./comp1.component";
import { Comp2Component } from "./comp2.component";
import { ErrorComponent } from "./error.component";

@NgModule({
  imports:      [
    BrowserModule,
    FormsModule,
    // ルーターにルートを指定
    RouterModule.forRoot([
      // URLの「:id」部分がパラメーター名を表す
      { path: "comp1/:id", component: Comp1Component },
      { path: "comp2", component: Comp2Component },
      { path: "", component: HomeComponent },
      { path: "**", component: ErrorComponent }
    ])
  ],
  declarations: [
    AppComponent,
    HomeComponent,
    Comp1Component,
    Comp2Component,
    ErrorComponent
  ],
  bootstrap:    [ AppComponent ]
})

export class AppModule { }
